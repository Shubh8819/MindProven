package com.EmployeeDeartment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDeartmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
